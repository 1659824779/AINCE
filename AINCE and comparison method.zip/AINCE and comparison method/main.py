# encoding utf-8
# keras version == 1.2.1
# tensorflow-gpu == 1.15.0
# keras version == 2.2.5
# tensorflow == 2.0.0

import sys
import numpy as np
import torch
from tqdm import tqdm
import datetime
import time
import cv2

import keras.backend as K
from keras import initializers
from keras.utils import np_utils
from keras.callbacks import Callback
from keras.models import Model, Sequential
from keras.optimizers import Adam, SGD, RMSprop
#from keras.engine.topology import Layer
#from layer import Add, Multiply, Subtract
from keras.layers import Dense, Input, Activation, Layer, Lambda, Softmax, Add, Multiply, Subtract
from keras.layers import Reshape, Conv1D, GlobalAveragePooling1D, GlobalMaxPooling1D, Concatenate, MaxPooling1D, AveragePooling1D
from keras.losses import kullback_leibler_divergence

from argparse import ArgumentParser
from matplotlib import pyplot as plt
from scipy.io import loadmat
from torch.utils.data import Dataset, DataLoader
from sklearn.metrics import balanced_accuracy_score, accuracy_score
from sklearn.cluster import KMeans

from callback import *
from HBP import build_model as build_HBP_model
from model import *

class Mydataset(Dataset):
    def __init__(self, path):
        self.rawdata = loadmat(path)
        self.data = self.rawdata['data']
        self.label = self.rawdata['label']

    def __getitem__(self, index):
        data = self.data[index]
        label = self.label[index]

        return data, label

    def __len__(self): 
        return len(self.label)
 
class Delta(Layer):
    def __init__(self, input_dim, output_dim, **kwargs):
        super(Delta, self).__init__(**kwargs)

        self.input_dim = input_dim
        self.output_dim = output_dim
        self.initializer = initializers.get('zero')

    def build(self, input_shape):
        self.var = self.add_weight(shape = (self.input_dim, self.output_dim), 
                                       name = 'var',
                                       initializer = self.initializer, 
                                       trainable = True)
        self.grad = self.add_weight(shape = (self.input_dim, self.output_dim), 
                                       name = 'grad',
                                       initializer = self.initializer, 
                                       trainable = True)
        self.zero = K.zeros_like(self.grad)

        super(Delta, self).build(input_shape)
    
    def call(self, x, mask = None):
        temp = x - self.var + self.grad
        self.var = x
        self.grad = K.update(self.grad, self.zero)
        return temp



class Alpha(Layer):

    def __init__(self, **kwargs):
        super(Alpha, self).__init__(**kwargs)

        self.initializer = initializers.get('zero')

        self.weight = self.add_weight(shape = (),
                                      name = 'weight',
                                      initializer = self.initializer,
                                      trainable = True)
        
    def call(self, inputs):
        
        return self.weight * inputs

    def build(self, input_shape):
        super(Alpha, self).build(input_shape)

def DynamicRegularizer(inputs, rate):
    loss = 0
    for i in inputs:
        for j in inputs:
            loss += kullback_leibler_divergence(i, j)
        #loss += kullback_leibler_divergence(j, i)

    loss = K.mean(loss)
    length = len(inputs) * 2

    return rate * loss / length


class HedgeRegularizer(Layer):

    def __init__(self, rate, **kwargs):
        super(HedgeRegularizer, self).__init__(**kwargs)

        self.rate = rate
        
    def call(self, inputs):

        convert_inputs = tf.convert_to_tensor(inputs)
        
        # calculate euclidean similarity
        distance = 0
        #similarity = []
        length = len(inputs)
        deep_simi = []
        shallow_simi = []

        for i in range(length):
            for j in range(length):
                if i != j:
                    distance += K.sqrt(K.sum(K.square(inputs[i] - inputs[j])))

            similarity.append(distance)
        similarity = tf.convert_to_tensor(similarity)
        
        # find the input which has the max euclidean distance with others
        idx = K.argmax(similarity)
        max_distance = tf.gather(convert_inputs, idx)

        # find the input which has the max euclidean distance with others
        idx = K.argmin(similarity)
        min_distance = tf.gather(convert_inputs, idx)

        loss = 0
        for i in inputs:
            #for j in inputs:
            loss += kullback_leibler_divergence(max_distance, i) 
            loss += kullback_leibler_divergence(min_distance, i)

        loss = K.mean(loss)
        length = len(inputs) ** 2
        self.add_loss(self.rate * loss / length)

        return inputs

    def call(self, inputs):

        convert_inputs = tf.convert_to_tensor(inputs)
        
        # calculate euclidean similarity
        distance = 0
        length = len(inputs)
        if int(length * 0.5) < length:
            shallow_len = int(length * 0.5)
            deep_len = length - shallow_len
        else:
            shallow_len = deep_len = int(length * 0.5)
        deep_simi = []
        shallow_simi = []

        for i in range(shallow_len):
            for j in range(shallow_len):
                if i != j:
                    distance += K.sqrt(K.sum(K.square(inputs[i] - inputs[j])))

            shallow_simi.append(distance)
        shallow_simi = tf.convert_to_tensor(shallow_simi)
        
        for i in range(deep_len):
            for j in range(deep_len):
                if i != j:
                    distance += K.sqrt(K.sum(K.square(inputs[i + shallow_len] - inputs[j + shallow_len])))

            deep_simi.append(distance)
        deep_simi = tf.convert_to_tensor(deep_simi)

        # find the input which has the min euclidean distance with others
        idx = K.argmin(shallow_simi)
        shallow_distance = tf.gather(convert_inputs, idx)

        idx = K.argmin(deep_simi)
        deep_distance = tf.gather(convert_inputs, idx)

        loss = 0
        for idx in range(shallow_len):
            loss += kullback_leibler_divergence(shallow_distance, inputs[idx]) 

        for idx in range(deep_len):
            loss += kullback_leibler_divergence(deep_distance, inputs[idx + shallow_len]) 

        loss = K.mean(loss)
        length = len(inputs) ** 2
        self.add_loss(self.rate * loss / length)

        return inputs


class Normalization(Layer):

    def __init__(self, **kwargs):
        super(Normalization, self).__init__(**kwargs)

    def call(self, inputs):
        
        outputs = [''] * len(inputs)
        sumval = K.sum(inputs)

        for i in range(len(outputs)):
            outputs[i] = inputs[i] / sumval

        return outputs

    def build(self, input_shape):
        super(Normalization, self).build(input_shape)


def build_model(args):
    base_name = 'out'
    if args.hedge == True:
        outs = [''] * args.layers
        outputs = [''] * args.layers
        out_name = ['']*args.layers

        N = args.layers
        for i in range(len(outs)):
            outs[i] = base_name + str(i)
            out_name[i] = base_name + str(i)
    else:
        outs = base_name
        out_name = [base_name]
        N = args.layers
    in_name = 'in0'

    inputs = Input(args.input_shape, name = in_name)

    for j in range(N):
        if j == 0:
            res = inputs
            layer = Dense(args.hidden_nums, kernel_initializer = 'he_normal', name = "fc" + str(j))(inputs)
            '''res = Dense(args.hidden_nums, kernel_initializer = 'he_normal')(res)

            #temp = Delta(args.batch_size, args.hidden_nums)(res)
            temp = Dense(args.hidden_nums, kernel_initializer = 'he_normal')(res)
            transform_gate = Activation('sigmoid')(temp)
            carry_gate = Lambda(lambda x: 1.0 - x)(transform_gate)
            carry_gate = Multiply()([carry_gate, res])
            transform_gate = Multiply()([transform_gate, layer])
            layer = Add()([transform_gate, carry_gate])'''
            
            layer = Activation('relu')(layer)
            if args.hedge == True:
                outs[j] = Dense(args.output_class, kernel_initializer = 'he_normal', activation = 'softmax', name = out_name[j])(layer)

            continue
        
        res = layer
        layer = Dense(args.hidden_nums, kernel_initializer = 'he_normal', name = "fc" + str(j))(layer)

        #temp = Delta(args.batch_size, args.hidden_nums)(res)
        '''temp = Dense(args.hidden_nums, kernel_initializer = 'he_normal')(res)
        transform_gate = Activation('sigmoid')(temp)
        carry_gate = Lambda(lambda x: 1.0 - x)(transform_gate) 
        carry_gate = Multiply()([carry_gate, res])
        transform_gate = Multiply()([transform_gate, layer])
        layer = Add()([transform_gate, carry_gate])'''
        
        layer = Activation('relu')(layer)
        if args.hedge == True:
            outs[j] = Dense(args.output_class, kernel_initializer = 'he_normal', activation = 'softmax', name = out_name[j])(layer)


    model = Model(inputs = inputs , outputs = outs)

    return (model, out_name)

def build_regular_model(args):
    base_name = 'out'
    if args.hedge == True:
        outs = [''] * args.layers
        outputs = [''] * args.layers
        out_name = ['']*args.layers

        N = args.layers
        for i in range(len(outs)):
            outs[i] = base_name + str(i)
            out_name[i] = base_name + str(i)
    else:
        outs = base_name
        out_name = [base_name]
        N = args.layers
    in_name = 'in0'

    inputs = Input(args.input_shape, name = in_name)

    for j in range(N):
        if j == 0:
            res = inputs
            layer = Dense(args.hidden_nums, kernel_initializer = 'he_normal', name = "fc" + str(j))(inputs)
            '''res = Dense(args.hidden_nums, kernel_initializer = 'he_normal')(res)

            #temp = Delta(args.batch_size, args.hidden_nums)(res)
            temp = Dense(args.hidden_nums, kernel_initializer = 'he_normal')(res)
            transform_gate = Activation('sigmoid')(temp)
            carry_gate = Lambda(lambda x: 1.0 - x)(transform_gate)
            carry_gate = Multiply()([carry_gate, res])
            transform_gate = Multiply()([transform_gate, layer])
            layer = Add()([transform_gate, carry_gate])'''
            
            layer = Activation('relu')(layer)
            if args.hedge == True:
                outs[j] = Dense(args.output_class, kernel_initializer = 'he_normal', activation = 'softmax')(layer)

            continue
        
        res = layer
        layer = Dense(args.hidden_nums, kernel_initializer = 'he_normal', name = "fc" + str(j))(layer)

        #temp = Delta(args.batch_size, args.hidden_nums)(res)
        '''temp = Dense(args.hidden_nums, kernel_initializer = 'he_normal')(res)
        transform_gate = Activation('sigmoid')(temp)
        carry_gate = Lambda(lambda x: 1.0 - x)(transform_gate) 
        carry_gate = Multiply()([carry_gate, res])
        transform_gate = Multiply()([transform_gate, layer])
        layer = Add()([transform_gate, carry_gate])'''
        
        layer = Activation('relu')(layer)
        if args.hedge == True:
            outs[j] = Dense(args.output_class, kernel_initializer = 'he_normal', activation = 'softmax')(layer)

    outs = HedgeRegularizer(args.regular_rate)(outs)

    for j in range(len(outputs)):
        outputs[j] = Lambda(lambda x:x+0, name = out_name[j])(outs[j])

    model = Model(inputs = inputs , outputs = outputs)

    return (model, out_name)

def build_convolution_model(args):
    outs = [''] * args.layers
    outputs = [''] * args.layers
    out_name = ['']*args.layers


    for i in range(args.layers):
        out_name[i] = 'out' + str(i)


    inputs = Input(args.input_shape)
    layer = Reshape(target_shape = (args.input_shape[0], 1))(inputs)

    for i in range(args.layers):

        res = layer
        
        conv7 = Conv1D(filters = 128, kernel_size = 1, strides = 1, padding = 'same', kernel_initializer = 'he_normal', activation = 'relu')(layer)
        conv7 = Conv1D(filters = 128, kernel_size = 7, strides = 1, padding = 'same', kernel_initializer = 'he_normal', activation = 'relu')(conv7)

        conv5 = Conv1D(filters = 128, kernel_size = 1, strides = 1, padding = 'same', kernel_initializer = 'he_normal', activation = 'relu')(layer)
        conv5 = Conv1D(filters = 128, kernel_size = 5, strides = 1, padding = 'same', kernel_initializer = 'he_normal', activation = 'relu')(conv5)

        conv3 = Conv1D(filters = 128, kernel_size = 1, strides = 1, padding = 'same', kernel_initializer = 'he_normal', activation = 'relu')(layer)
        conv3 = Conv1D(filters = 128, kernel_size = 3, strides = 1, padding = 'same', kernel_initializer = 'he_normal', activation = 'relu')(conv3)

        #conv1 = Conv1D(filters = 128, kernel_size = 1, strides = 1, padding = 'same', kernel_initializer = 'he_normal', activation = 'relu')(layer)

        layer = Concatenate()([conv3, conv5, conv7])
        layer = Conv1D(filters = 128, kernel_size = 1, strides = 1, padding = 'same', kernel_initializer = 'he_normal', activation = 'relu')(layer)
        
        """ weight = GlobalMaxPooling1D()(layer)
        
        weight = Reshape((1, 128))(weight)
        weight = Dense(100, kernel_initializer = 'he_normal', activation = 'relu')(layer)
        weight = Dense(128, kernel_initializer = 'he_normal', activation = 'sigmoid')(weight) """
        

        #weight = Dense(64, kernel_initializer = 'he_normal', activation = 'sigmoid')(layer)
        #layer = Multiply()([layer, weight])
        
        
        if i == 0:
            res = Conv1D(filters = 128, kernel_size = 1, strides = 1, padding = 'same', kernel_initializer = 'he_normal')(res)

        
        transform_gate = Dense(128,  kernel_initializer = 'he_normal', activation = 'sigmoid')(res)
        carry_gate = Lambda(lambda x: 1.0 - x)(transform_gate) 
        carry_gate = Multiply()([carry_gate, res])
        transform_gate = Multiply()([transform_gate, layer])
        layer = Add()([transform_gate, carry_gate])
        '''
        q =  Conv1D(filters = 128, kernel_size = 1, strides = 1, padding = 'same', kernel_initializer = 'he_normal')(res)
        k =  Conv1D(filters = 128, kernel_size = 1, strides = 1, padding = 'same', kernel_initializer = 'he_normal')(layer)
        v =  Conv1D(filters = 128, kernel_size = 1, strides = 1, padding = 'same', kernel_initializer = 'he_normal')(layer)

        
        k = Permute(dims = (2, 1))(k)
        kq = Dot(axes = (1, 2))([k, q])
        
        kq = Activation('sigmoid')(kq)
        layer = Dot(axes = 1)([kq, v])
        '''

        out = GlobalMaxPooling1D()(layer)
        outs[i] = Dense(args.output_class, kernel_initializer = 'he_normal', activation = 'softmax')(out)
    
    outs = HedgeRegularizer(rate = args.regular_rate)(outs)

    for i in range(len(outputs)):
        outputs[i] = Lambda(lambda x:x+0, name = out_name[i])(outs[i])
    
    model = Model(inputs = inputs , outputs = outputs)

    return model, out_name

def build_attention_model(args):

    AttentionNet = Sequential(layers = [Dense(100, kernel_initializer = 'he_normal', use_bias = True, activation = 'relu'),
                                        Dense(100, kernel_initializer = 'he_normal', use_bias = True, activation = 'relu'),
                                        Dense(1, kernel_initializer = 'he_normal', use_bias = True, activation = 'softmax')])
    
    outputs = ['']*args.layers
    attention = ['']*args.layers
    inputs = Input(args.input_shape)

    for i in range(args.layers):

        if i == 0:
            layer = Dense(args.hidden_nums, kernel_initializer = 'he_normal', name = "fc" + str(i))(inputs)
            outputs[i] =  Dense(args.output_class, kernel_initializer = 'he_normal')(layer)
            attention[i] = AttentionNet(outputs[i])
            
        else:
            layer = Dense(args.hidden_nums, kernel_initializer = 'he_normal', name = "fc" + str(i))(layer)
            outputs[i] =  Dense(args.output_class, kernel_initializer = 'he_normal')(layer)
            attention[i] = AttentionNet(outputs[i])
    
    attention = Normalization()(attention)

    for i in range(args.layers):
        outputs[i] = Multiply()([outputs[i], attention[i]])
        #outputs[i] = Activation('softmax')(outputs[i])

    out = Add()(outputs)
    out = Activation('softmax')(out)
    model = Model(inputs = inputs, outputs = out)

    return model

def build_loss_weight(args):
    if args.hedge == False:
        w = [1.]
    else:
        w = [1./ args.layers] * args.layers

    return w

def predict(input, model, callback, args):
    pred = model.predict(input, batch_size = args.batch_size)
    pred = [a*b for a, b in zip(pred, callback.weights)]
    pred = np.argmax(np.sum(pred, axis=0), axis=1)

    return pred


def build_loss_name(out_name):
    if len(out_name) == 1:
        out_name_loss = ['loss']
    else:
        out_name_loss = [s + '_loss' for s in out_name]
    
    return out_name_loss

def build_acc_name(out_name):
    if len(out_name) == 1:
        out_name_acc = ['acc']
    else:
        out_name_acc = [s + '_acc' for s in out_name]
    
    return out_name_acc



def main(arg):
    parser = ArgumentParser('My Project')

    # Training Paramters
    parser.add_argument('--learning_rate',type = float, default = 0.001) # 0.01 0.005 0.001 0.0005
    parser.add_argument('--regular_rate', type = float, default = 0.01)
    parser.add_argument('--batch_size',   type = int,   default = 100)
    parser.add_argument('--optim',        type = str,   default = 'Adam')
    parser.add_argument('--epoch',        type = int,   default = 1) 

    # Dataset Path
    parser.add_argument('--dataset_name', type = str,   default = 'kddcup99')
    parser.add_argument('--path',         type = str,   default = 'C:/Users/40481/Desktop/dataset/kddcup99.mat')
    parser.add_argument('--save',         type = bool,  default = True)


    # Model Parameters
    parser.add_argument('--input_shape',  type = int,   default = (3,)) 
    parser.add_argument('--output_class', type = int,   default = 2)
    parser.add_argument('--hidden_nums',  type = list,  default = 100)
    parser.add_argument('--layers',       type = int,   default = 8) 
    parser.add_argument('--hedge',        type = bool,  default = True)
    
    args = parser.parse_args()

    if args.dataset_name == 'covtype':
        args.output_class = 7
        args.input_shape = (54,)

    elif args.dataset_name == 'kddcup99':
        args.output_class = 23
        args.input_shape = (41,)
    
    elif args.dataset_name == 'elec':
        args.output_class = 2
        args.input_shape = (6,)

    elif args.dataset_name == 'weather':
        args.output_class = 3
        args.input_shape = (9,)

    elif args.dataset_name == 'sea_gene':
        args.output_class = 2
        args.input_shape = (3,)

    elif args.dataset_name == 'hyperplane':
        args.output_class = 2
        args.input_shape = (10,)

    elif args.dataset_name == 'RBFBlips':
        args.output_class = 4
        args.input_shape = (20,)

    elif args.dataset_name == 'LED' or args.dataset_name == 'LED_gradual':
        args.output_class = 10
        args.input_shape = (24,)
    
    elif args.dataset_name == 'tree':
        args.output_class = 10
        args.input_shape = (30,)

    elif args.dataset_name == 'sensor':
        args.output_class = 55
        args.input_shape = (5,)
    
    print('At ',datetime.datetime.now().strftime("%m%d-%H%M%S")," Start Training ", args.dataset_name, "dataset")
    print("==========\nArgs:{}\n==========".format(args))

    dataset = Mydataset(path = args.path)
    dataloader = DataLoader(dataset = dataset, batch_size = args.batch_size) 
     
    #regular_model, out_name = build_model(args)
    regular_model, out_name = build_regular_model(args)

    #regular_model, out_name = build_convolution_model(args)
    #model = build_attention_model(args)
    out_name_loss = build_loss_name(out_name)
    out_name_acc = build_acc_name(out_name)

    #optim = keras.optimizers.Adam(lr = args.learning_rate)
    #optim2 = keras.optimizers.Adam(lr = args.learning_rate)
    optim2 = eval(args.optim)(lr = args.learning_rate)
    #loss = keras.losses.CategoricalCrossentropy(label_smoothing = 0)
    loss_dict = dict((k, 'categorical_crossentropy') for k in out_name)
    #loss_list = list(loss for i in range(args.layers))
    
    loss_weights = build_loss_weight(args)
    #my_callback = MyCallback(loss_weights, loss_names = out_name_loss, acc_names = out_name_acc, hedge = args.hedge)
    regular_callback = MyCallback(loss_weights, loss_names = out_name_loss, acc_names = out_name_acc, hedge = args.hedge)
    #my_callback = DynamicCallback(loss_weights, loss_names = out_name_loss, acc_names = out_name_acc, hedge = args.hedge)
    #model.compile(optimizer = optim1, loss = loss_dict, loss_weights = loss_weights,  metrics = ['accuracy'], hedge = True)
    regular_model.compile(optimizer = optim2, loss = loss_dict, loss_weights = loss_weights,  metrics = ['accuracy'], hedge = False)
    
    #model.build(input_shape = (None, args.input_shape[0]))
    
    """ for i in range(len(model.layers)):
        layer = model.get_layer(index = i)
        
        if 'fc' in layer.name or 'out' in layer.name:
            regular_layer = regular_model.get_layer(index = i)
            regular_layer.set_weights(layer.get_weights()) """
    
    acclist = []
    total = 0
    true = 0
    cumuacclist = []
    losslist = []

    acclist2 = []
    total2 = 0
    true2 = 0
    cumuacclist2 = []
    losslist2 = []

    iteration = 0
        

    start = time.clock()
    for data, label in tqdm(dataloader):

        data = data.numpy()
        label = label.numpy()  
        onehotlabel = np_utils.to_categorical(label, args.output_class)

        
        """ acc = model.evaluate(data, onehotlabel, verbose = 0)
        acclist.append(acc[1])
        total += acc[1]
        cumuacclist.append(total / len(acclist)) """

        """ pred = predict(data, model, my_callback, args)
        #pred = model.predict(input, batch_size = args.batch_size)
        #pred = np.argmax(pred, axis=1)
    

        acclist.append(balanced_accuracy_score(label, pred))
        for i in range(len(pred)):
            if pred[i] == label[i]:
                true += 1
        total += args.batch_size
        cumuacclist.append(true / total) """

        pred = predict(data, regular_model, regular_callback, args)
        acclist2.append(balanced_accuracy_score(label, pred))
        for i in range(len(pred)):
            if pred[i] == label[i]:
                true2 += 1
        total2 += args.batch_size
        cumuacclist2.append(true2 / total2)

        onehotlabel = dict((k, onehotlabel) for k in out_name)
        """ history = model.fit(data, onehotlabel, epochs = args.epoch, verbose = 0, batch_size = args.batch_size, callbacks = [my_callback])
        losslist.append(history.history["loss"]) """
        history = regular_model.fit(data, onehotlabel, epochs = args.epoch, verbose = 0, batch_size = args.batch_size, callbacks = [regular_callback])
        losslist2.append(history.history["loss"])

        #layer = model.get_layer(name = 'fc8')



        #os.mkdir("d:/weightvalueshow/SEADL/" + args.dataset_name + "/" + str(iteration))

        """ for idx in range(82):

            layer = model.get_layer(index = idx)
            name = layer.get_config()["name"]

            if "fc" in name:

                weight = layer.get_weights()[0]

                weight = scaler.fit_transform(weight) * 255
                weight = cv2.resize(weight, (0, 0), fx = 2, fy = 2, interpolation = cv2.INTER_LINEAR)

                path = "d:/weightvisualization/SEADL8/" + args.dataset_name + "/" + name + "/" + str(iteration) +".jpg"
                
                path = path.replace("fc", "layer")
                
                cv2.imwrite(path, weight)
                cv2.waitKey(0) """
        
        
        iteration += 1
        
        
    end = time.clock()
    print("time cost:", end - start)

    #np.savetxt(r'd:/weightvisualization/SEADL8/' + args.dataset_name + '/weight.txt', my_callback.weight_list, fmt = '%s')
    
       
    
    print('At ', datetime.datetime.now().strftime("%m%d-%H%M%S"), " Training", args.dataset_name, " OVER.")
    print(regular_callback.weights)
    """ print("average real-time accuracy of model: ",np.mean(acclist))
    print("cumulative accuracy of model: ",cumuacclist[len(cumuacclist)-1]) """

    print("average real-time accuracy of regular_model: ",np.mean(acclist2))
    print("cumulative accuracy of regular_model: ",cumuacclist2[len(cumuacclist2)-1])


    plt.title('training loss')
    #plt.plot(losslist, label = 'model')
    plt.plot(losslist2, label = 'regular_model')
    plt.legend()
    plt.show()

    plt.title('cumulative accuracy curve')
    #plt.plot(cumuacclist, label = 'model')
    plt.plot(cumuacclist2, label = 'regular_model')
    plt.legend()
    plt.show()

    plt.title('real-time accuracy curve')
    #plt.plot(acclist, label = 'model')
    plt.plot(acclist2, label = 'regular_model')
    plt.legend()
    plt.show()

'''
    if args.save:
        np.savetxt(r'C:/Users/40481/Desktop/HedgeRegular/layer' + str(args.layers) + '/' + args.dataset_name + '/losslist.txt', losslist2, fmt = '%s')
        np.savetxt(r'C:/Users/40481/Desktop/HedgeRegular/layer' + str(args.layers) + '/' + args.dataset_name + '/acclist.txt', acclist2, fmt = '%s')
        np.savetxt(r'C:/Users/40481/Desktop/HedgeRegular/layer' + str(args.layers) + '/' + args.dataset_name + '/cumuacclist.txt', cumuacclist2, fmt = '%s')
'''


if __name__ == '__main__':
    main(sys.argv[1:])
     
