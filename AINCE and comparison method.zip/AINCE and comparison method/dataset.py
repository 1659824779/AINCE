# encoding utf-8

import os
from tqdm import tqdm
from scipy.io import loadmat

class LoadDataset(object):

    def __init__(self, path, batch_size, **kwargs):
        
        self.path = path
        self.batch_size = batch_size

        if not os.path.exists(self.path):
            raise RuntimeError("'{}' is not exists".format(self.path))

        self.rawdata = loadmat(self.path)
        self.data = self.rawdata['data']
        self.label = self.rawdata['label']
        self.len = len(self.data)
        
        self.pos = 0

    def __iter__(self):

        return self

    def __next__(self):
        
        if (self.pos + self.batch_size) >= self.len:
            
            data, label =  self.data[self.pos : self.len - 1], self.label[self.pos : self.len - 1]
            self.pos = -1
        
        elif self.pos < self.len and self.pos >= 0:

            data, label = self.data[self.pos : self.pos + self.batch_size], self.label[self.pos : self.pos + self.batch_size]
            self.pos += self.batch_size

        else:

            raise StopIteration()

        return data, label    

    def len(self):

        len = len(self.data) / self.batch_size

        if not len == int(len):
            
            len = int(len) + 1

        return len


if __name__ == "__main__":
    dataset = LoadDataset(path = "E:/hua/dataset/flare_solar_2drift.mat", batch_size = 100)

    for data, label in tqdm(dataset):
        print(len(label))