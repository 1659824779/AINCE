# encoding utf-8

import sys
import numpy as np
import keras
import torch
from tqdm import tqdm
from keras.utils import np_utils
from keras.callbacks import Callback
from keras.models import Model, Sequential
from keras.optimizers import Adam, SGD
from argparse import ArgumentParser
from matplotlib import pyplot as plt
from scipy.io import loadmat
from keras.layers import Dense, Activation, Input
from torch.utils.data import Dataset, DataLoader
from sklearn.metrics import balanced_accuracy_score



class Mydataset(Dataset):
    def __init__(self, path):
        self.rawdata = loadmat(path)
        self.data = self.rawdata['data']
        self.label = self.rawdata['label']          

    def __getitem__(self, index):
        data = torch.from_numpy(self.data[index]).float()
        label = torch.from_numpy(self.label[index]).long()

        return data, label

    def __len__(self): 
        return len(self.label)

def build_dnn_model(args):
    inputs = Input(args.input_shape)
    for i in range(args.layers):
        if i == 0:
            layer = Dense(args.hidden_nums, kernel_initializer = 'he_normal', activation = 'relu')(inputs)
        elif i == args.layers-1:
            layer = Dense(args.output_class, kernel_initializer = 'he_normal', activation = 'softmax')(layer)
        else:
            layer = Dense(args.hidden_nums, kernel_initializer = 'he_normal', activation = 'relu')(layer)


    model = Model(inputs = inputs , outputs = layer)

    return model



def predict(input, model, callback):
    pred = model.predict(input)
    pred = [a*b for a, b in zip(pred, callback.weights)]
    pred = np.argmax(np.sum(pred, axis=0), axis=1)

    return pred
def build_loss_name(out_name):
    if len(out_name) == 1:
        out_name_loss = ['loss']
    else:
        out_name_loss = [s + '_loss' for s in out_name]
    
    return out_name_loss

def main(arg):
    parser = ArgumentParser('My Project')

    # Hyperparameters
    parser.add_argument('--lr',           type = float, default = 0.01)
    parser.add_argument('--batch_size',   type = int,   default = 100)
    parser.add_argument('--optim',        type = str,   default = 'Adam')
    parser.add_argument('--epoch',        type = int,   default = 1)

    # Dataset Path
    parser.add_argument('--dataset_name', type = str,   default = 'sea_gene')
    parser.add_argument('--path',         type = str,   default = 'C:/Users/40481/Desktop/dataset/sea_gene.mat')

    # Model Parameters
    parser.add_argument('--input_shape',  type = int,   default = (10,))
    parser.add_argument('--output_class', type = int,   default = 10)
    parser.add_argument('--hidden_nums',  type = int,   default = 100)
    parser.add_argument('--layers',       type = int,   default = 8)
    parser.add_argument('--hedge',        type = bool,  default = True)
    parser.add_argument('--shortcut',     type = bool,  default = True)
    parser.add_argument('--gate',         type = bool,  default = True)
    args = parser.parse_args()

    if args.dataset_name == 'covtype':
        args.output_class = 7
        args.input_shape = (54,)

    elif args.dataset_name == 'kddcup99':
        args.output_class = 23
        args.input_shape = (41,)
    
    elif args.dataset_name == 'elec':
        args.output_class = 2
        args.input_shape = (6,)

    elif args.dataset_name == 'weather':
        args.output_class = 3
        args.input_shape = (9,)

    elif args.dataset_name == 'sea_gene':
        args.output_class = 2
        args.input_shape = (3,)

    elif args.dataset_name == 'hyperplane':
        args.output_class = 2
        args.input_shape = (10,)

    elif args.dataset_name == 'RBFBlips':
        args.output_class = 4
        args.input_shape = (20,)

    elif args.dataset_name == 'LED' or args.dataset_name == 'LED_gradual':
        args.output_class = 10
        args.input_shape = (24,)

    elif args.dataset_name == 'tree':
        args.output_class = 10
        args.input_shape = (30,)


    dataset = Mydataset(path = args.path)
    dataloader = DataLoader(dataset = dataset, batch_size = args.batch_size)

    dnnlist = []


    
    dnn2 = build_dnn_model(args)
    dnnlist.append(dnn2)
    '''
    args.layers = 4
    dnn3 = build_model(args)
    dnnlist.append(dnn3)
    
    args.layers = 4
    dnn5 = build_model(args)
    dnnlist.append(dnn5)
    
    
    args.layers = 8
    dnn8 = build_model(args)
    dnnlist.append(dnn8)
    
    args.layers = 10
    dnn10 = build_model(args)
    dnnlist.append(dnn10)
    
    args.layers = 12
    dnn15 = build_model(args)
    dnnlist.append(dnn15)
    '''

    for i in range(len(dnnlist)):
        optim = eval(args.optim)(lr = args.lr)
        dnnlist[i].compile(optimizer = optim, loss = 'categorical_crossentropy', metrics = ['accuracy'])

    acclist = []
    cumuacclist = []
    losslist = []
    for i in range(len(dnnlist)):
        templist = []
        acclist.append(templist)
        templist = []
        cumuacclist.append(templist)
        templist = []
        losslist.append(templist)

    true = [0]*len(dnnlist)
    total = 0
   
    for input, target in tqdm(dataloader):
        input = input.numpy()
        target = target.squeeze().numpy()
        total += args.batch_size
        fittarget = np_utils.to_categorical(target, args.output_class)
        
        for i in range(len(dnnlist)):
            pred = dnnlist[i].predict(input)
            pred = np.argmax(pred, axis = 1)
            acclist[i].append(balanced_accuracy_score(target, pred))
            
            for j in range(len(pred)):
                if pred[j] == target[j]:
                    true[i] += 1

            cumuacclist[i].append(true[i] / total)
            history = dnnlist[i].fit(input, fittarget, epochs = args.epoch, verbose = 0, batch_size = args.batch_size)
            losslist[i].append(history.history['loss'])
        
    np.savetxt(r'C:/Users/40481/Desktop/losslist.txt', losslist[0], fmt = '%s')
    np.savetxt(r'C:/Users/40481/Desktop/cumuacclist.txt', cumuacclist[0], fmt = '%s')
    np.savetxt(r'C:/Users/40481/Desktop/acclist.txt', acclist[0], fmt = '%s')
    
    print("Traing", args.dataset_name, "finished!")
    i = 0
    for i in range(len(dnnlist)):
        print("average training accuracy of", 'DNN' + str(i+1) + 'model', np.mean(acclist[i]))
    
    for i in range(len(dnnlist)):
        print("training accuracy of DNN model: ",cumuacclist[i][len(cumuacclist[i])-1])


    plt.title('training loss') 
    for i in range(len(dnnlist)):
        plt.plot(losslist[i], label = 'DNN' + str(i+1) + 'model')
    plt.legend()
    plt.show()

    plt.title('training accuracy')
    for i in range(len(dnnlist)):
        plt.plot(cumuacclist[i], label = 'DNN' + str(i+1) + 'model')
    plt.legend()
    plt.show()

    plt.title('training accuracy curve')
    for i in range(len(dnnlist)):
        plt.plot(range(len(acclist[i])), acclist[i], label = 'DNN' + str(i+1) + 'model')
    plt.legend()
    plt.show()


if __name__ == '__main__':
    #for i in range(5):
    main(sys.argv[1:])
