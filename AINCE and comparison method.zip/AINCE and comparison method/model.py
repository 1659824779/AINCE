import keras
import keras.backend as K
from keras import initializers
from keras.models import Model
from keras.layers import Dense, Activation, Lambda, Layer, Add, Multiply, Subtract, Softmax
#from keras.engine.topology import Layer
import tensorflow as tf

from collections import OrderedDict

def build_name(num):
    base = 'output_'
    outname = []

    for i in range(num):
        outname.append(base + str(i + 1))

    return outname

class Delta(Layer):

    def __init__(self, input_dim, output_dim, **kwargs):

        super(Delta, self).__init__(**kwargs)

        self.input_dim = input_dim
        self.output_dim = output_dim
        self.initializer = initializers.get('zero')

    def build(self, input_shape):

        self.var = self.add_weight(shape = (self.input_dim, self.output_dim), 
                                   name = 'var',
                                   initializer = self.initializer, 
                                   trainable = True)

        self.grad = self.add_weight(shape = (self.input_dim, self.output_dim), 
                                    name = 'grad',
                                    initializer = self.initializer, 
                                    trainable = True)

        self.zero = K.zeros_like(self.grad)

        super(Delta, self).build(input_shape)
    
    def call(self, x, mask = None):

        temp = x - self.var + self.grad
        self.var = x
        self.grad = K.update(self.grad, self.zero)

        return temp

class Bottleneck(Model):

    def __init__(self, output_dim, firstblock = False, **kwargs):

        super(Bottleneck, self).__init__()

        self.output_dim = output_dim
        self.firstblock = firstblock

        self.dense1 = Dense(units = self.output_dim, kernel_initializer = 'he_normal')
        self.dense2 = Dense(units = self.output_dim, kernel_initializer = 'glorot_normal', activation = 'sigmoid')
        self.dense3 = Dense(units = self.output_dim, kernel_initializer = 'he_normal')
        #self.delta = Delta(100, self.output_dim)
        self.relu = Activation('relu')
        self.add = Add()
        self.multiply = Multiply()
        self.lambda1 = Lambda(lambda x: 1.0 - x)

    def call(self, inputs):

        identity = inputs
        if self.firstblock:
            identity = self.dense3(identity)

        deep = self.dense1(inputs)

        #gate = self.delta(identity)
        gate = self.dense2(identity)
        transform_gate = self.lambda1(gate)
        carry_gate = self.multiply([gate, deep])
        transform_gate = self.multiply([transform_gate, identity])

        out = self.add([carry_gate, transform_gate])
        out = self.relu(out)

        return out

class MutualRegularizer(Layer):

    def __init__(self, rate = 0.01):

        super(MutualRegularizer, self).__init__()

        self.rate = rate
        self.loss = tf.zeros([])
        self.var = K.constant(value = 1e-8)
    
    def call(self, inputs):

        self.loss = tf.zeros([])
        for pred1 in inputs:
            for pred2 in inputs:
                if pred1 != pred2:
                    self.loss += (K.log(1e-8 + K.softmax(pred2) / (K.softmax(pred1) + 1e-8)))
        
        self.loss  = self.rate * self.loss / len(inputs)
        self.add_loss(self.loss)
        
        return inputs


class MutualModel(Model):

    def __init__(self, input_dim, output_dim, hidden_nums, blocks, **kwargs):

        super(MutualModel, self).__init__()

        self.input_dim = input_dim
        self.output_dim = output_dim
        self.hidden_nums = hidden_nums
        self.blocks = blocks
        #self.regularizer = MutualRegularizer()

        self.outname = build_name(num = blocks)

        #self.layerlist = OrderedDict()
        #self.clflist = OrderedDict()
        self.layerlist = [''] * self.blocks
        self.clflist = [''] * self.blocks
        self.outputs = [''] * self.blocks

        for i in range(self.blocks):

            if i == 0:
                #self.layerlist['bottleneck' + str(i)] = Bottleneck(self.hidden_nums, firstblock = True)
                self.layerlist[i] = Dense(self.hidden_nums, kernel_initializer = 'he_normal', activation = 'relu')
            
            else:
                #self.layerlist['bottleneck' + str(i)] = Bottleneck(self.hidden_nums, firstblock = False)
                self.layerlist[i] = Dense(self.hidden_nums, kernel_initializer = 'he_normal', activation = 'relu')

            self.clflist[i] = Dense(units = self.output_dim, kernel_initializer = 'he_normal', activation = 'softmax', name = self.outname[i])

    def call(self, inputs):
        
        for i in range(self.blocks):
            inputs = self.layerlist[i](inputs)
            self.outputs[i] = self.clflist[i](inputs)

        #self.regularizer(output)

        return self.outputs

if __name__ == '__main__':
    model = MutualModel(input_dim = 20, output_dim = 4, hidden_nums = 100, blocks = 8) 
    loss_dict = dict((outname, 'categorical_crossentropy') for outname in model.outname)
    model.compile(loss = loss_dict, metrics = ['accuracy'], optimizer = 'SGD')
    #model.compile(loss = None, metrics = ['accuracy'])
    model.build(input_shape = (None, 20))
    model.summary()       