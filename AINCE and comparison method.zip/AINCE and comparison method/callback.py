import os, sys
import numpy as np
import copy

import keras
import keras.callbacks
from keras.callbacks import Callback



class MyCallback(Callback):
    def __init__(self, w, beta = 0.99, loss_names = [], acc_names = [], hedge = False):
        self.weights = w
        self.beta = beta
        self.names = loss_names
        self.hedge = hedge
        self.acc_names = acc_names
        self.l = []

    def on_batch_end(self, batch, logs = {}):

        weighted_loss = logs.get('loss')
        self.l.append(weighted_loss)

        losses = [logs[name] for name in self.names]
        
        accs = [logs[name] for name in self.acc_names]
        

        if self.hedge:
            
            M = sum(losses)
            losses = [loss / M for loss in losses]
            min_loss = np.amin(losses)
            max_loss = np.amax(losses)
            range_of_loss = max_loss - min_loss
            if range_of_loss != 0 :
                losses = [(loss-min_loss)/range_of_loss for loss in losses]
                
            alpha = [self.beta ** loss for loss in losses] 

            alpha = [a * w for a, w in zip(alpha, self.weights)]
            
            alpha = [ max(0.01, a) for a in alpha]
   
            M = sum(alpha)

            alpha = [a / M for a in alpha]

            #maxidx = np.argmin(losses)

            #alpha = np.zeros_like(losses)

            #alpha[maxidx] = 1

            self.weights = alpha  

    def on_batch_begin(self, epoch, logs={}):
        self.model.holder = (self.weights)



class CustomCallback(Callback):
    def __init__(self, w, beta = 0.99, loss_names = [], acc_names = [], hedge = False):
        self.weights = w
        self.beta = beta
        self.names = loss_names
        self.l = []
        self.hedge = hedge
        self.loss_list = []
        self.weight_list = []
        self.acc_list = []
        self.acc_names = acc_names

        self.loss_buffer = []
        self.driftalarm = False
        self.stationaryalarm = False
        self.middlealarm = False

        self.isinmodel = [True for i in range(len(self.weights))]
        self.layers = len(self.weights)
        self.totallayers = self.layers
        self.threshold = 1 / (self.layers + 1)
        self.save_weights = self.weights
        

    def on_batch_end(self, batch, logs = {}):

        weighted_loss = logs.get('loss')
        self.l.append(weighted_loss)

        losses = [logs[name] for name in self.names]
        self.loss_list.append(losses)
        self.weight_list.append(self.weights)
        accs = [logs[name] for name in self.acc_names]
        self.acc_list.append(accs)

        if self.hedge:
            #self.beta = 1 / (1 + 10 * np.exp(weighted_loss)) + 0.9
            
            M = sum(losses)
            losses = [loss / M for loss in losses]
            min_loss = np.amin(losses)
            max_loss = np.amax(losses)
            range_of_loss = max_loss - min_loss
            if range_of_loss != 0 :
                losses = [(loss-min_loss)/range_of_loss for loss in losses]
                
            alpha = [self.beta ** loss for loss in losses]    
                

            alpha = [a * w for a, w in zip(alpha, self.weights)]
               
            M = sum(alpha)

            alpha = [a / M for a in alpha]


            if len(self.l) >= 5:
                loss_buffer = self.l[-5:]
                self.loss_buffer.append(np.mean(loss_buffer))

            if len(self.loss_buffer) >= 5:

                site = self.loss_buffer[-6:-1]
                
                self.driftalarm = False

                for s in site:
                    if np.abs(self.loss_buffer[-1] - s) > 0.25:
                        self.driftalarm = True
                        break


                if self.driftalarm == False:

                    self.stationaryalarm = True

                    for s in site: 
                        if np.abs(self.loss_buffer[-1] - s) > 0.02:
                            self.stationaryalarm = False
                            break   
            

            # Add shallow base classifier when concept drift occurs
            # find shallow classifier from the left half

            if self.driftalarm == True and self.layers < self.totallayers:
                maxidx = np.argmax(alpha)

                for idx in range(maxidx):
                    if self.isinmodel[idx] == True:
                       
                        weightsum = 0
                        for i in range(self.totallayers):
                            if self.isinmodel[i]:
                                print(self.save_weights)
                                weightsum += self.save_weights[idx-1]['ensembleweight'][i]

                        alpha[idx] = (self.save_weights[idx]['weight'] / weightsum) 
                        
                        self.isinmodel[idx] = True
                        
                        self.layers += 1
                        break

            # Add deep base classifier when data stream is stationary
            # Find deep classifier from the right half

            elif self.stationaryalarm == True and self.layers < self.totallayers:
                maxidx = np.argmax(alpha)

                for idx in range(maxidx, self.totallayers):
                    if self.isinmodel[idx] == False:
                        
                        
                        weightsum = 0
                        for i in range(self.totallayers):
                            if self.isinmodel[i]:
                                weightsum += self.save_weights[idx]['ensembleweight'][i]

                        alpha[idx] = self.save_weights[idx]['weight'] / weightsum

                        self.isinmodel[idx] = True
                        self.layers += 1
                        break
                        
            
            # Freeze poor base classifier which has lower weight

            elif self.driftalarm == False and self.stationaryalarm == False and self.layers > 1:

                for idx in range(self.totallayers):
                    
                    if self.isinmodel[idx] == True and alpha[idx] < 0.1 and (idx == 0 or idx == self.totallayers - 1 or (idx > 0 and self.isinmodel[idx - 1] == False) or (idx < self.totallayers - 1 and self.isinmodel[idx + 1] == False)):
                        
                        self.layers -= 1
                        self.isinmodel[idx] = False
                        temp = copy.deepcopy(alpha)
                        self.save_weights[idx] = {'weight':temp[idx], 'ensembleweight':temp}
                        alpha[idx] = 0

                        break


            M = sum(alpha)
            alpha = [a / M for a in alpha]
        
            self.weights = alpha

    def on_batch_begin(self, epoch, logs={}):
        self.model.holder = (self.weights)