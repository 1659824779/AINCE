# encoding utf-8

import numpy as np
import keras
from keras.models import Model, Sequential
from keras.layers import Dense, Activation, Input, Add, Multiply, Lambda


def build_resnet_model(args):
    
    N = args.layers - 1
    in_name = 'in0'
    base_name = 'out'

    inputs = Input(args.input_shape, name = in_name)
    for j in range(N):
        if j == 0:
            res = inputs
            res =  Dense(args.hidden_nums, kernel_initializer = 'he_normal')(res)

            layer = Dense(args.hidden_nums, kernel_initializer = 'he_normal')(inputs)
            layer = Activation('relu')(layer)
            continue

        elif j % 2 == 1:
            layer = Dense(args.hidden_nums, kernel_initializer = 'he_normal')(layer)
            layer = Add()([res, layer])
            layer = Activation('relu')(layer)

        elif j % 2 == 0:
            res = layer
            layer = Dense(args.hidden_nums, kernel_initializer = 'he_normal')(layer)
            layer = Activation('relu')(layer)
        
    out = Dense(args.output_class, kernel_initializer = 'he_normal', activation = 'softmax')(layer)
    model = Model(inputs = inputs , outputs = out)


    return model