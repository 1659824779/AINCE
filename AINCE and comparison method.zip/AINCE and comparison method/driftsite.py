import pandas as pd
import numpy as np
f = pd.read_csv(r'C:/Users/40481/Desktop/HedgeRegular/layer8/tree/acclist.txt', header = None)

f = np.array(f).squeeze().tolist()
startsite = 749

site = startsite
for i in range(250):
    interval = f[site + 1: site + 21]
    left = f[site + 1: site + 10]
    right = f[site + 11: site + 21]
    point = f[site]

    if np.abs(point - np.mean(interval)) <= 0.003 and np.abs(np.mean(left) - np.mean(right)) <= 0.003:
        avgacc = np.mean(f[startsite: site])
        step = site - startsite
        print("average acc:", avgacc)
        print("step:", step)
        print("RSA:", step * (1 - avgacc))
        break
    else:
        site += 1
 
    
    

