# encoding utf-8

import os, sys
import numpy as np
import keras
import keras.callbacks
import torch
from tqdm import tqdm
from keras.utils import np_utils
from keras.callbacks import Callback
from keras.models import Model, Sequential
from keras.optimizers import SGD, Adam
from skmultiflow.drift_detection import ADWIN
from argparse import ArgumentParser
from matplotlib import pyplot as plt
from scipy.io import loadmat
from keras.layers import Dense, Activation, Input
from torch.utils.data import Dataset, DataLoader
from sklearn.metrics import accuracy_score, balanced_accuracy_score

class Mydataset(Dataset):
    def __init__(self, path):
        self.rawdata = loadmat(path)
        self.data = self.rawdata['data']
        self.label = self.rawdata['label']

    def __getitem__(self, index):
        data = torch.from_numpy(self.data[index]).float()
        label = torch.from_numpy(self.label[index]).long()

        return data, label

    def __len__(self): 
        return len(self.data)

def build_model(args):
    base_name = 'out'
    if args.hedge == True:
        outs = [''] * args.layers
        out_name = ['']*args.layers

        N = args.layers
        for i in range(len(outs)):
            outs[i] = base_name + str(i)
            out_name[i] = base_name + str(i)
    else:
        outs = base_name
        out_name = [base_name]
        N = args.layers - 1
    in_name = 'in0'

    inputs = Input(args.input_shape, name = in_name)

    for j in range(N):
        if j == 0:
            layer = Dense(args.hidden_nums, )(inputs)
            layer = Activation('relu')(layer)
            if args.hedge == True:
                outs[j] = Dense(args.output_class, activation = 'softmax', name = outs[j])(layer)
        
            continue
        
        layer = Dense(args.hidden_nums)(layer)
        layer = Activation('relu')(layer)
        if args.hedge == True:
            outs[j] = Dense(args.output_class, activation = 'softmax', name = outs[j])(layer)
        
    if args.hedge == False:
        outs = Dense(args.output_class, activation = 'softmax', name = outs)(layer)

    
    model = Model(input = inputs , output = outs)

    return (model, out_name)


class MyCallback(Callback):
    def __init__(self, w, beta = 0.99, names = [], hedge = False):
        self.weights = w
        self.beta = beta
        self.names = names
        self.l = []
        self.hedge = hedge
        self.alpha = w
        self.loss = []
        self.w = []

        
        self.idx = len(self.alpha)-1
        self.layers = self.idx
        self.threshold = 1/len(self.alpha)

    def on_batch_end(self, batch, logs = {}):
        self.l.append(logs.get('loss'))
        losses = [logs[name] for name in self.names]
        self.loss.append(losses)
        self.w.append(self.weights)

        if self.hedge:
            M = sum(losses)
            losses = [loss / M for loss in losses]
            min_loss = np.amin(losses)
            max_loss = np.amax(losses)
            range_of_loss = max_loss - min_loss
            if range_of_loss != 0 :
                losses = [(loss-min_loss)/range_of_loss for loss in losses]
            alpha = [self.beta ** loss for loss in losses]
             
            try:
                alpha = [a * w for a, w in zip(alpha, self.weights)]
            except ValueError:
                pass
           
            alpha = [ max(0.01, a) for a in alpha]

            M = sum(alpha)
            alpha = [a / M for a in alpha]
 
            M = sum(alpha)
            alpha = [a / M for a in alpha]
            
            self.weights = alpha 
    def on_batch_begin(self, epoch, logs={}):
        self.model.holder = (self.weights)

def build_loss_weight(args):
    if args.hedge == False:
        w = [1.]
    else:
        if args.shortcut:
            w = [1./ (args.layers*2)] * args.layers*2
        else:
             w = [1./ args.layers] * args.layers
    return w

def predict(input, model, callback):
    pred = model.predict(input)
    pred = [a*b for a, b in zip(pred, callback.weights)]
    pred = np.argmax(np.sum(pred, axis=0), axis=1)

    return pred
def build_loss_name(out_name):
    if len(out_name) == 1:
        out_name_loss = ['loss']
    else:
        out_name_loss = [s + '_loss' for s in out_name]
    
    return out_name_loss

def main(arg):
    parser = ArgumentParser('My Project')

    # Hyperparameters
    parser.add_argument('--lr',           type = float, default = 0.01)
    parser.add_argument('--batch_size',   type = int,   default = 100)
    parser.add_argument('--optim',        type = str,   default = 'Adam')
    parser.add_argument('--epoch',        type = int,   default = 1)
    # Dataset Path
    parser.add_argument('--dataset_name', type = str,   default = 'RBFblips')
    parser.add_argument('--path',         type = str,   default = 'C:/Users/40481/Desktop/dataset/RBFblips.mat')

    # Model Parameters
    parser.add_argument('--input_shape',  type = int,   default = (20,))
    parser.add_argument('--output_class', type = int,   default = 4)
    parser.add_argument('--hidden_nums',  type = int,   default = 100)
    parser.add_argument('--layers',       type = int,   default = 10)
    parser.add_argument('--hedge',        type = bool,  default = True)
    parser.add_argument('--shortcut',     type = bool,  default = False)
    args = parser.parse_args()

    dataset = Mydataset(path = args.path)
    dataloader = DataLoader(dataset = dataset, batch_size = args.batch_size)

    model1, out_name = build_model(args)
    out_name_loss = build_loss_name(out_name)
    
    optim = eval(args.optim)(lr = args.lr)
    loss_dict = dict((k, 'categorical_crossentropy') for k in out_name) 

    loss_weights = build_loss_weight(args)
    my_callback1 = MyCallback(loss_weights, names = out_name_loss, hedge = args.hedge)
    model1.compile(optimizer = optim, loss = loss_dict, loss_weights = loss_weights, metrics = ['accuracy'])
    model1.summary()

    acclist1 = []

    for input, target in tqdm(dataloader):
        input = input.numpy()
        target = target.squeeze().numpy()

        pred = predict(input, model1, my_callback1)
        acclist1.append(balanced_accuracy_score(target, pred))

                
        target1 = np_utils.to_categorical(target, 4)
        target1 = dict((k, target1) for k in out_name)
        model1.fit(input, target1, epochs = 1, verbose = 0, batch_size = args.batch_size, callbacks=[my_callback1])

    plt.plot(my_callback1.l)
    plt.show()

    plt.plot(range(len(acclist1)), acclist1, label = 'HBP')

    plt.legend()
    plt.show()


    '''
    # Generate weight distribution
    draw_list = []
    for idx in range(2 * config['n_layers']):
        if idx % 2 != 0:
            layer = model.get_layer(index = idx)
            weight_Dense, bias_Dense = layer.get_weights()
            draw_list.append(np.abs(np.sum(weight_Dense)))

    draw_list /= np.sum(draw_list)
    print(draw_list)

    # Draw weight distribution (histogram)
    plt.bar(range(len(draw_list)), draw_list)
    plt.ylabel("Weight distribution")
    plt.xlabel("Layer")
    plt.title("Layer = "+ str(config['n_layers']))
    plt.savefig(r'C:/Users/40481/Desktop/' + ' ' + str(1) + '.png')
    plt.show()
    '''


if __name__ == '__main__':

    main(sys.argv[1:])
