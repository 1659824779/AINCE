import Orange
import matplotlib.pyplot as plt


plt.rc('font',family='Times New Roman') 
names = ["DNN-2", "DNN-4", "DNN-8", "DNN-16", "Resnet", "Highway", "HBP", "MLCNN"]
averageranks = [3.78, 4.56, 6.11, 7.22, 5.78, 3.89, 3.33, 1.33]
cd = Orange.evaluation.compute_CD(averageranks, 10, test = 'bonferroni-dunn')
print(cd)
Orange.evaluation.graph_ranks(averageranks, names, cd=cd, width=6, textspace=1.5)
plt.show()