# 定义变量名和值的字典
variables_dict = {
    'DWM': 1.96, 'ASHT': 1.88, 'OBC': 1.52, 'RUS': 4.56, 'LEV': 2.42,
    'ARF': 4.84, 'SRP': 8.52, 'DWCDS': 4.69, 'DNN': 15.22, 'ResNET': 21.49,
    'Highway': 17.56, 'HBP': 0.87, 'Densenet': 0.19, 'AINCE': 24.20
}

# 按值排序并保留变量名
sorted_items = sorted(variables_dict.items(), key=lambda x: x[1])

# 输出排序后的变量名和值
for name, value in sorted_items:
    print(f"{name}: {value}")